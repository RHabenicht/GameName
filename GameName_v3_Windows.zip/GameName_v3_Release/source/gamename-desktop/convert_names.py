"""Build GameName NAM lists from an existing Namebot checkout."""
import argparse
import itertools
import json
from pathlib import Path
import re
import sys
import unicodedata
import zipfile

REGIONS = {
    'american': 'American English', 'british': 'British English',
    'australian': 'Australian English', 'new_zealand': 'New Zealand English',
}
GEORDI = {
    'geordi_gizmo_company': 'Geordi Gizmo Company',
    'geordi_gizmo_science': 'Geordi Gizmo Technical',
}

# These source headers name Joel Crook as the compiler.
JOEL_CROOK_IPT = {
    'FrenchNames.ipt',
    'NorwegianNames.ipt',
    'PolishNames.ipt',
    'PortugueseNames.ipt',
    'RussianNames.ipt',
    'ScottishNames.ipt',
    'SpanishNames.ipt',
    'SwedishNames.ipt',
    'TurkishNames.ipt',
}


def unique(values):
    result = {}
    for value in values:
        value = ' '.join(unicodedata.normalize('NFC', value).split())
        if value:
            result.setdefault(value.casefold(), value)
    return list(result.values())


def write_nam(path, credit, male, female, family=(), precomposed=False, family_first=False, additions=()):
    lines = ['COMMENT', '"' + credit + '"', '']
    for section, values in [('MALE', male), ('FEMALE', female), ('LAST NAMES', family), ('ADDITIONS', additions)]:
        values = unique(values)
        if values:
            lines.extend([section, f' {len(values)}'])
            lines.extend(f' {index} {value}' for index, value in enumerate(values, 1))
            lines.append('')
    lines.extend(['DEFAULTS', 'number of given names=1',
                  'number of family names=' + ('0' if precomposed or not family else '1'),
                  'number of additions=0', 'use different files=false',
                  'family name first=' + str(family_first).lower(), '', 'END', ''])
    path.write_bytes('\r\n'.join(lines).encode('utf-8'))


def source_credit(files):
    formats = {Path(file).suffix.lower() for file in files}
    if {'.nam', '.ipt'} <= formats:
        return 'Gurth and Joel Crook'
    if formats == {'.nam'}:
        return 'Gurth'
    return ''


MERGED_NAMES = {
    'danish': 'Danish', 'dutch': 'Dutch', 'german': 'German',
    'irish': 'Irish', 'italian': 'Italian', 'japanese': 'Japanese',
    'hindi_legacy': 'Hindi',
}


def export_merged(path, resource, sources):
    pools = resource['pools']
    given = pools['given']
    write_nam(
        path, 'Sources: ' + ', '.join(sources) + '. Credit: ' + source_credit(sources) + '.',
        [r['value'] for r in given if 'male' in r['genders']],
        [r['value'] for r in given if 'female' in r['genders']],
        [r['value'] for r in pools['family']],
        additions=[r['value'] for r in pools.get('addition', [])],
    )


# Selected from the source's Chinese pools. The larger pools also contain
# names from other romanization systems and entries of uncertain origin.
CHINESE_NAMES = {
    'family': """
        Wang Li Zhang Liu Chen Yang Huang Zhao Wu Zhou Xu Sun Ma Zhu Hu Guo He
        Luo Gao Lin Zheng Liang Xie Song Tang Deng Han Cao Peng Xiao Tian Dong
        Yuan Pan Yu Jiang Cai Du Ye Cheng Wei Su Lu Ding Ren Shen Yao Fan Zhong
        Cui Tan Liao Fu Bai Meng Qiu Hou Shi Shao Fang Qin Dai Xia Wan Jiang
    """,
    'male': """
        Aiguo Bingwen Boqin Delun Deming Donghai Guangli Guoliang
        Guowei Guozhi Jianguo Jianjun Jianyu Jingguo Jinhai Junjie
        Liwei Longwei Pengfei Qingshan Renshu Shaoqing Shihong Shoushan
        Shunyuan Tengfei Tingfeng Tingguang Weimin Weisheng Weiyuan Weizhe
        Wencheng Xianliang Xiaobo Xiaojian Xiaosheng Xiaowen Yingjie Yongliang
        Yongnian Yongrui Yusheng Zhaohui Zhengsheng Zhengzhong Zhiqiang Zihao
    """,
    'female': """
        Aihong Baozhai Biyu Caihong Caixia Caiyun Changying Chunhua
        Chuntao Cuifen Dailan Daiyu Dandan Dongmei Fenfang Hualing
        Huifang Huifen Huiqing Jiayi Jiaying Jingfei Jinghua Jinjing
        Kexin Lanfen Lanying Lifen Lihua Lijuan Liling Meifen
        Meifeng Meihui Meili Meilin Meirong Meiwen Meixiang Meixiu
        Meiying Mingxia Mingyan Mingzhu Qiaohui Qiaolian Qingmei Qiuyue
        Ruolan Shilan Shuchun Songlian Suyin Wanqing Wanying Wenling
        Xiaohui Xiaolian Xiaoling Xiaoqing Xiaotong Xiulan Xiurong Xiuying
        Yanmei Zhilan
    """,
}


def export_chinese(path, resource):
    allowed = {
        'family': {r['value'] for r in resource['pools']['family']},
        **{gender: {r['value'] for r in resource['pools']['given'] if gender in r['genders']}
           for gender in ('male', 'female')},
    }
    names = {key: unique(values.split()) for key, values in CHINESE_NAMES.items()}
    for key, values in names.items():
        missing = set(values) - allowed[key]
        if missing:
            raise ValueError(f'Unverified Chinese {key} entries: {sorted(missing)}')
    write_nam(path, 'Chinese names in Mandarin romanization. Surname first. Credits: Gurth and Joel Crook. Joel Crook compiled ChineseNames.ipt.',
              names['male'], names['female'], names['family'], family_first=True)
    return {key: len(values) for key, values in names.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent / 'names')
    args = parser.parse_args()
    sys.path.insert(0, str(args.checkout.resolve() / 'tools'))
    from namebot import Engine

    def load(path):
        return json.loads((args.checkout / path).read_text(encoding='utf-8'))

    args.output.mkdir(parents=True, exist_ok=True)
    catalog = load('catalog.json')['resources']
    manifest = []
    merged_sources = {file for entry in catalog if entry['id'] in MERGED_NAMES for file in entry['source_files']}
    with zipfile.ZipFile(args.checkout / 'backup/source_tables.zip') as archive:
        for member in archive.namelist():
            name = Path(member).name
            if '/lists/' in member and name.endswith('.nam') and name not in {'English.nam', 'American.nam'} | merged_sources:
                (args.output / name).write_bytes(archive.read(member))
                manifest.append({'file': name, 'source': name, 'method': 'original NAM'})

    english = load('data/english.json')
    for profile in english['profiles']:
        name = REGIONS.get(profile['id'])
        if not name:
            continue
        tags = set(profile['eligible_profile_tags'])
        given = [r for r in english['pools']['given'] if tags.intersection(r['profiles'])]
        family = [r['value'] for r in english['pools']['family'] if tags.intersection(r['profiles'])]
        file = name + '.nam'
        write_nam(args.output / file, 'Gurth and Joel Crook. See Namebot ENRICHMENT.md for the regional sources.',
                  [r['value'] for r in given if 'male' in r['genders']],
                  [r['value'] for r in given if 'female' in r['genders']], family)
        manifest.append({'file': file, 'method': 'regional component export', 'credit': 'Gurth and Joel Crook'})

    for entry in catalog:
        resource = load(entry['file'])
        if entry['id'] in MERGED_NAMES:
            file = MERGED_NAMES[entry['id']] + '.nam'
            export_merged(args.output / file, resource, entry['source_files'])
            manifest.append({'file': file, 'sources': entry['source_files'],
                             'method': 'merged name components',
                             'credit': source_credit(entry['source_files'])})
            continue
        if entry['id'] == 'chinese':
            file = 'ChineseNames.nam'
            counts = export_chinese(args.output / file, resource)
            manifest.append({'file': file, 'source': 'ChineseNames.ipt',
                             'method': 'curated Chinese component export', 'counts': counts,
                             'credit': 'Gurth and Joel Crook'})
            continue
        engine = Engine(resource, seed=521)
        for program in resource['programs']:
            source = program['source']
            if not program['entrypoint'] or not source.lower().endswith('.ipt'):
                continue
            # English IPT is represented by the four regional component exports.
            if entry['id'] == 'english':
                continue
            file = GEORDI.get(program['id'], Path(source).stem) + '.nam'
            prompts = program['prompts']
            choices = list(itertools.product(*(p['choices'] for p in prompts)))
            outputs = [engine.generate(program['id'], dict(zip([p['id'] for p in prompts], combo)))
                       for combo in choices for _ in range(2500)]
            names = unique(re.sub(r'\s*\*\s*$', '', value) for value in outputs)
            if not names:
                raise ValueError(f'Empty export: {source}')
            credit = source_credit(entry['source_files'])
            if not credit and (program['id'] in GEORDI or source in JOEL_CROOK_IPT):
                credit = 'Joel Crook'
            if source == 'Old Norse Names.ipt':
                credit = 'reverie_13'
            comment = f'Fixed list sampled from {source}.'
            if credit:
                comment += f' Credit: {credit}.'
            write_nam(args.output / file, comment, names, names, precomposed=True)
            manifest.append({'file': file, 'source': source, 'method': 'seeded static sample',
                             'unique_outputs': len(names), 'credit': credit})

    latin = load('data/latin.json')
    engine = Engine(latin, seed=521)
    male, female = ([engine.generate(f'roman_{gender}') for _ in range(2500)]
                    for gender in ('male', 'female'))
    write_nam(args.output / 'Roman Latin.nam', 'Christian Schwietzke and Nightlife.', male, female, precomposed=True)
    manifest.append({'file': 'Roman Latin.nam', 'method': 'seeded static sample',
                     'credit': 'Christian Schwietzke and Nightlife'})
    for culture in ('hawaiian', 'khmer', 'filipino'):
        data = load(f'data/{culture}.json')
        engine = Engine(data, seed=521)
        male, female = ([engine.generate(f'{culture}_{gender}') for _ in range(2500)]
                        for gender in ('male', 'female'))
        file = culture.title() + '.nam'
        write_nam(args.output / file, 'See Namebot ENRICHMENT.md for sources.',
                  male, female, precomposed=True)
        manifest.append({'file': file, 'method': 'seeded static sample'})
    (args.output.parent / 'EXPORTS.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
