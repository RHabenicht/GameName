Unicode true
VIProductVersion "3.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "GameName"
VIAddVersionKey /LANG=1033 "ProductVersion" "3.0.0"
VIAddVersionKey /LANG=1033 "FileVersion" "3.0.0.0"
VIAddVersionKey /LANG=1033 "CompanyName" "NightLife"
VIAddVersionKey /LANG=1033 "FileDescription" "GameName v3 Setup by NightLife"
VIAddVersionKey /LANG=1033 "OriginalFilename" "GameName_v3_Setup.exe"
VIAddVersionKey /LANG=1033 "LegalCopyright" "GameName v3 by NightLife"
VIAddVersionKey /LANG=1033 "Comments" "GameName v1 by Gurth, v2 by Tobias Diekershoff, v3 by NightLife"
!include "MUI2.nsh"
!define MUI_ICON "GameName.ico"
!define MUI_UNICON "GameName.ico"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP "Setup_Header.bmp"
!define MUI_HEADERIMAGE_UNBITMAP "Setup_Header.bmp"
Name "GameName"
OutFile "../../GameName_v3_Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\GameName"
InstallDirRegKey HKCU "Software\GameName" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
ShowInstDetails show
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

; Setup and Uninstall share a lock. Keep the handle until the process exits.
Var SetupMutex

!macro AcquireSetupMutex failureMessage
  System::Call 'kernel32::CreateMutexW(p 0, i 0, w "Local\NightLife.GameName.Setup") p .r0 ?e'
  Pop $1
  StrCpy $SetupMutex $0
  ${If} $1 == 183
    Abort
  ${EndIf}
  ${If} $SetupMutex == 0
    MessageBox MB_ICONSTOP|MB_OK "${failureMessage}"
    Abort
  ${EndIf}
!macroend

Function .onInit
  !insertmacro AcquireSetupMutex "GameName Setup could not start."
FunctionEnd

Function un.onInit
  !insertmacro AcquireSetupMutex "GameName Uninstall could not start."
FunctionEnd

Section "GameName"
  SetOutPath "$INSTDIR"
  File "GameName.exe"
  File /oname=README.txt "../../README.txt"
  File "../../CHANGELOG.txt"
  File "../../COPYING.txt"
  File "../../MAKE_NAME_LISTS.txt"
  SetOutPath "$INSTDIR\examples"
  File "../../examples/Manual Example.nam"
  File "../../examples/AI Example.nam"
  SetOutPath "$INSTDIR"
  File "names.go"
  File "main_windows.go"
  File "splash_windows.go"
  File "GameName_Splash.png"
  File "names_test.go"
  File "GameName.nsi"
  File "GameName.ico"
  File "GameName.manifest"
  File "remove-bundled.nsh"
  File "../gamename-desktop/convert_names.py"
  File "../gamename-desktop/EXPORTS.json"
  SetOutPath "$INSTDIR\names"
  File "../gamename-desktop/names/*.nam"
  Delete "$INSTDIR\names\DanishNames.nam"
  Delete "$INSTDIR\names\DutchNames.nam"
  Delete "$INSTDIR\names\GermanNames.nam"
  Delete "$INSTDIR\names\IrishName.nam"
  Delete "$INSTDIR\names\ItalianName.nam"
  Delete "$INSTDIR\names\JapaneseName.nam"
  Delete "$INSTDIR\names\JapaneseNames.nam"
  Delete "$INSTDIR\names\Hindi 2.nam"
  SetOutPath "$INSTDIR"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\GameName"
  CreateShortCut "$SMPROGRAMS\GameName\GameName.lnk" "$INSTDIR\GameName.exe"
  CreateShortCut "$SMPROGRAMS\GameName\Uninstall GameName.lnk" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\GameName" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "DisplayName" "GameName"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "Publisher" "NightLife"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "DisplayVersion" "3.0.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "DisplayIcon" "$INSTDIR\GameName.ico"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop" "NoRepair" 1
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\GameName\GameName.lnk"
  Delete "$SMPROGRAMS\GameName\Uninstall GameName.lnk"
  RMDir "$SMPROGRAMS\GameName"
  Delete "$INSTDIR\GameName.exe"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\README.txt"
  Delete "$INSTDIR\CHANGELOG.txt"
  Delete "$INSTDIR\COPYING.txt"
  Delete "$INSTDIR\MAKE_NAME_LISTS.txt"
  Delete "$INSTDIR\examples\Manual Example.nam"
  Delete "$INSTDIR\examples\AI Example.nam"
  RMDir "$INSTDIR\examples"
  Delete "$INSTDIR\names.go"
  Delete "$INSTDIR\main_windows.go"
  Delete "$INSTDIR\splash_windows.go"
  Delete "$INSTDIR\GameName_Splash.png"
  Delete "$INSTDIR\names_test.go"
  Delete "$INSTDIR\GameName.nsi"
  Delete "$INSTDIR\GameName.ico"
  Delete "$INSTDIR\GameName.manifest"
  Delete "$INSTDIR\remove-bundled.nsh"
  Delete "$INSTDIR\convert_names.py"
  Delete "$INSTDIR\EXPORTS.json"
  !include "remove-bundled.nsh"
  RMDir "$INSTDIR\names"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "Software\GameName"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GameNameDesktop"
SectionEnd
