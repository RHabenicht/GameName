package main

import (
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

var (
	user                                                                                 = syscall.NewLazyDLL("user32.dll")
	kernel                                                                               = syscall.NewLazyDLL("kernel32.dll")
	gdi                                                                                  = syscall.NewLazyDLL("gdi32.dll")
	dialog                                                                               = syscall.NewLazyDLL("comdlg32.dll")
	send                                                                                 = user.NewProc("SendMessageW")
	setText                                                                              = user.NewProc("SetWindowTextW")
	create                                                                               = user.NewProc("CreateWindowExW")
	defWindow                                                                            = user.NewProc("DefWindowProcW")
	window, instance, font                                                               uintptr
	setBox, maleButton, femaleButton, noMiddleButton, middleButton, resultBox, statusBox uintptr
	countBox                                                                             uintptr
	activePath                                                                           string
	activeList                                                                           nameList
	paths                                                                                []string
	dpi                                                                                  uintptr = 96
	canvasBrush, headerBrush, cardBrush                                                  uintptr
	labels                                                                               = make(map[uintptr]labelStyle)
)

type rect struct{ left, top, right, bottom int32 }
type labelStyle struct{ ink, brush uintptr }

func px(n int) uintptr              { return uintptr(n) * dpi / 96 }
func color(r, g, b uintptr) uintptr { return r | g<<8 | b<<16 }
func brush(r, g, b uintptr) uintptr {
	result, _, _ := gdi.NewProc("CreateSolidBrush").Call(color(r, g, b))
	return result
}
func makeFont(size, weight int) uintptr {
	result, _, _ := gdi.NewProc("CreateFontW").Call(
		uintptr(-int(px(size))), 0, 0, 0, uintptr(weight), 0, 0, 0,
		1, 0, 0, 5, 0, uintptr(unsafe.Pointer(ptr("Segoe UI"))))
	return result
}
func label(title string, face, ink, background uintptr, x, y, w, h int) uintptr {
	hwnd := control("STATIC", title, 0, 0, x, y, w, h)
	send.Call(hwnd, 0x30, face, 1)
	labels[hwnd] = labelStyle{ink, background}
	return hwnd
}
func fill(hdc, b uintptr, x, y, right, bottom int) {
	area := rect{int32(px(x)), int32(px(y)), int32(px(right)), int32(px(bottom))}
	user.NewProc("FillRect").Call(hdc, uintptr(unsafe.Pointer(&area)), b)
}

type point struct{ x, y int32 }
type message struct {
	hwnd           uintptr
	message        uint32
	wparam, lparam uintptr
	time           uint32
	pt             point
	private        uint32
}
type windowClass struct {
	size, style                              uint32
	procedure                                uintptr
	classExtra, windowExtra                  int32
	instance, icon, cursor, background, menu uintptr
	name                                     *uint16
	smallIcon                                uintptr
}
type openFileName struct {
	size                                             uint32
	owner, instance, filter, customFilter            uintptr
	maxCustomFilter, filterIndex                     uint32
	file                                             uintptr
	maxFile                                          uint32
	fileTitle                                        uintptr
	maxFileTitle                                     uint32
	initialDir, title                                uintptr
	flags                                            uint32
	fileOffset, extension                            uint16
	defaultExtension, data, hook, template, reserved uintptr
	reservedSize, flagsEx                            uint32
}

func ptr(s string) *uint16            { p, _ := syscall.UTF16PtrFromString(s); return p }
func text(hwnd uintptr, value string) { setText.Call(hwnd, uintptr(unsafe.Pointer(ptr(value)))) }
func control(class, title string, style uintptr, id, x, y, w, h int) uintptr {
	var exStyle uintptr
	if class == "EDIT" || class == "LISTBOX" {
		exStyle = 0x200
	}
	hwnd, _, _ := create.Call(exStyle, uintptr(unsafe.Pointer(ptr(class))), uintptr(unsafe.Pointer(ptr(title))), 0x50000000|style,
		px(x), px(y), px(w), px(h), window, uintptr(id), instance, 0)
	send.Call(hwnd, 0x30, font, 1)
	return hwnd
}
func populateLists(folder, preferred string) {
	files, _ := filepath.Glob(filepath.Join(folder, "*.nam"))
	paths = files
	send.Call(setBox, 0x184, 0, 0)
	selection := 0
	for i, path := range files {
		send.Call(setBox, 0x180, 0, uintptr(unsafe.Pointer(ptr(filepath.Base(path)))))
		if strings.EqualFold(path, preferred) {
			selection = i
		}
	}
	if len(files) > 0 {
		send.Call(setBox, 0x186, uintptr(selection), 0)
	}
}
func configPath() string {
	folder, err := os.UserConfigDir()
	if err != nil {
		return ""
	}
	return filepath.Join(folder, "GameNameDesktop", "last-list.txt")
}
func load(path string) {
	list, err := loadList(path)
	if err != nil {
		text(statusBox, err.Error())
		return
	}
	activePath, activeList = path, list
	text(statusBox, filepath.Base(path)+"\r\n"+list.comment)
	if config := configPath(); config != "" {
		if os.MkdirAll(filepath.Dir(config), 0700) == nil {
			_ = os.WriteFile(config, []byte(path), 0600)
		}
	}
}
func loadSelected() {
	selected, _, _ := send.Call(setBox, 0x188, 0, 0)
	if selected < uintptr(len(paths)) {
		load(paths[selected])
	}
}
func chooseFile() {
	filter := []uint16{'G', 'a', 'm', 'e', 'N', 'a', 'm', 'e', ' ', 'f', 'i', 'l', 'e', 's', 0, '*', '.', 'n', 'a', 'm', 0, 0}
	buffer := make([]uint16, 32768)
	data := openFileName{owner: window, filter: uintptr(unsafe.Pointer(&filter[0])),
		file: uintptr(unsafe.Pointer(&buffer[0])), maxFile: uint32(len(buffer)), flags: 0x1808}
	data.size = uint32(unsafe.Sizeof(data))
	ok, _, _ := dialog.NewProc("GetOpenFileNameW").Call(uintptr(unsafe.Pointer(&data)))
	runtime.KeepAlive(filter)
	runtime.KeepAlive(buffer)
	if ok != 0 {
		path := syscall.UTF16ToString(buffer)
		populateLists(filepath.Dir(path), path)
		load(path)
	}
}
func checked(button uintptr) bool {
	result, _, _ := send.Call(button, 0xf0, 0, 0)
	return result == 1
}
func requestedCount() (int, bool) {
	var input [16]uint16
	user.NewProc("GetWindowTextW").Call(countBox, uintptr(unsafe.Pointer(&input[0])), uintptr(len(input)))
	count, err := strconv.Atoi(strings.TrimSpace(syscall.UTF16ToString(input[:])))
	if err != nil || count < 1 || count > 100 {
		user.NewProc("MessageBoxW").Call(window, uintptr(unsafe.Pointer(ptr("Enter a count from 1 to 100."))),
			uintptr(unsafe.Pointer(ptr("GameName"))), 0x30)
		user.NewProc("SetFocus").Call(countBox)
		send.Call(countBox, 0xb1, 0, ^uintptr(0))
		return 0, false
	}
	return count, true
}

func showResults(results []string) {
	text(resultBox, strings.Join(results, "\r\n"))
	send.Call(resultBox, 0xb1, 0, 0)
	send.Call(resultBox, 0xb7, 0, 0)
}

func rollLetters(scrabble bool) {
	count, ok := requestedCount()
	if !ok {
		return
	}
	results := make([]string, count)
	for i := range results {
		results[i] = letterName(scrabble)
	}
	showResults(results)
}

func roll() {
	if activePath == "" {
		user.NewProc("MessageBoxW").Call(window, uintptr(unsafe.Pointer(ptr("First select a *.nam file!"))), uintptr(unsafe.Pointer(ptr("GameName"))), 0x30)
		return
	}
	gender := 1
	if checked(femaleButton) {
		gender = 2
	}
	count, ok := requestedCount()
	if !ok {
		return
	}
	results, err := activeList.generateWithMiddle(gender, count, checked(middleButton))
	if err != nil {
		text(statusBox, err.Error())
		return
	}
	showResults(results)
}
func addMenu() {
	newMenu := user.NewProc("CreateMenu")
	newPopup := user.NewProc("CreatePopupMenu")
	appendMenu := user.NewProc("AppendMenuW")
	root, _, _ := newMenu.Call()
	type item struct {
		id    uintptr
		label string
	}
	for _, group := range []struct {
		label string
		items []item
	}{
		{"&File", []item{{101, "Select Name File"}, {104, "Exit"}}},
		{"&Generate", []item{{102, "Random Name from File"}, {106, "Random Name"}, {107, "Scrabble Name"}}},
		{"&Help", []item{{108, "About"}}},
	} {
		popup, _, _ := newPopup.Call()
		for _, entry := range group.items {
			appendMenu.Call(popup, 0, entry.id, uintptr(unsafe.Pointer(ptr(entry.label))))
		}
		appendMenu.Call(root, 0x10, popup, uintptr(unsafe.Pointer(ptr(group.label))))
	}
	user.NewProc("SetMenu").Call(window, root)
}
func windowProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case 0x14:
		fill(wp, canvasBrush, 0, 0, 820, 524)
		fill(wp, headerBrush, 0, 0, 820, 72)
		fill(wp, cardBrush, 24, 92, 332, 502)
		fill(wp, cardBrush, 352, 92, 796, 502)
		return 1
	case 0x138:
		style, ok := labels[lp]
		if !ok && (lp == maleButton || lp == femaleButton || lp == noMiddleButton || lp == middleButton) {
			style, ok = labelStyle{color(28, 24, 35), cardBrush}, true
		}
		if ok {
			gdi.NewProc("SetTextColor").Call(wp, style.ink)
			gdi.NewProc("SetBkMode").Call(wp, 1)
			return style.brush
		}
	case 2:
		user.NewProc("PostQuitMessage").Call(0)
		return 0
	case 0x111:
		switch wp & 0xffff {
		case 101:
			chooseFile()
		case 102:
			roll()
		case 104:
			user.NewProc("DestroyWindow").Call(hwnd)
		case 105:
			loadSelected()
		case 106:
			rollLetters(false)
		case 107:
			rollLetters(true)
		case 108:
			user.NewProc("MessageBoxW").Call(window, uintptr(unsafe.Pointer(ptr("GameName v3 by NightLife\r\n\r\nGameName v1 by Gurth\r\nGameName v2 by Tobias Diekershoff"))), uintptr(unsafe.Pointer(ptr("About GameName"))), 0x40)
		case 109:
			if wp>>16 == 2 {
				loadSelected()
			}
		case 103:
			send.Call(resultBox, 0xb1, 0, ^uintptr(0))
			send.Call(resultBox, 0x301, 0, 0)
			send.Call(resultBox, 0xb1, 0, 0)
		}
		return 0
	}
	result, _, _ := defWindow.Call(hwnd, uintptr(msg), wp, lp)
	return result
}
func focusGameName() {
	find := user.NewProc("FindWindowW")
	for _, class := range []string{"GameNameSplash", "GameNameWindow"} {
		hwnd, _, _ := find.Call(uintptr(unsafe.Pointer(ptr(class))), 0)
		if hwnd == 0 {
			continue
		}
		if visible, _, _ := user.NewProc("IsWindowVisible").Call(hwnd); visible == 0 {
			continue
		}
		if minimized, _, _ := user.NewProc("IsIconic").Call(hwnd); minimized != 0 {
			user.NewProc("ShowWindowAsync").Call(hwnd, 9)
		}
		user.NewProc("SetForegroundWindow").Call(hwnd)
		return
	}
}

func main() {
	runtime.LockOSThread()
	mutex, _, err := kernel.NewProc("CreateMutexW").Call(0, 0,
		uintptr(unsafe.Pointer(ptr(`Local\NightLife.GameName.App`))))
	if mutex != 0 {
		defer kernel.NewProc("CloseHandle").Call(mutex)
	}
	if err == syscall.ERROR_ALREADY_EXISTS {
		focusGameName()
		return
	}
	if mutex == 0 {
		user.NewProc("MessageBoxW").Call(0, uintptr(unsafe.Pointer(ptr("GameName could not start."))),
			uintptr(unsafe.Pointer(ptr("GameName"))), 0x10)
		return
	}
	instance, _, _ = kernel.NewProc("GetModuleHandleW").Call(0)
	if getDpi := user.NewProc("GetDpiForSystem"); getDpi.Find() == nil {
		if current, _, _ := getDpi.Call(); current != 0 {
			dpi = current
		}
	}
	font = makeFont(16, 400)
	titleFont := makeFont(26, 600)
	sectionFont := makeFont(20, 600)
	smallFont := makeFont(14, 400)
	canvasBrush, headerBrush, cardBrush = brush(242, 240, 246), brush(14, 10, 22), brush(255, 255, 255)
	cursor, _, _ := user.NewProc("LoadCursorW").Call(0, 32512)
	loadIcon := user.NewProc("LoadImageW")
	largeIcon, _, _ := loadIcon.Call(instance, 2, 1, px(64), px(64), 0)
	smallIcon, _, _ := loadIcon.Call(instance, 2, 1, px(16), px(16), 0)
	class := windowClass{procedure: syscall.NewCallback(windowProc), instance: instance,
		cursor: cursor, background: canvasBrush, name: ptr("GameNameWindow"), icon: largeIcon, smallIcon: smallIcon}
	class.size = uint32(unsafe.Sizeof(class))
	user.NewProc("RegisterClassExW").Call(uintptr(unsafe.Pointer(&class)))
	const windowStyle = 0x00ca0000
	area := rect{right: int32(px(820)), bottom: int32(px(524))}
	user.NewProc("AdjustWindowRectEx").Call(uintptr(unsafe.Pointer(&area)), windowStyle, 1, 0)
	window, _, _ = create.Call(0, uintptr(unsafe.Pointer(ptr("GameNameWindow"))), uintptr(unsafe.Pointer(ptr("GameName"))), windowStyle,
		0x80000000, 0x80000000, uintptr(area.right-area.left), uintptr(area.bottom-area.top), 0, 0, instance, 0)
	if window == 0 {
		return
	}
	addMenu()

	headerIcon, _, _ := loadIcon.Call(instance, 2, 1, px(48), px(48), 0)
	logo := control("STATIC", "", 3, 0, 24, 12, 48, 48)
	send.Call(logo, 0x172, 1, headerIcon)
	labels[logo] = labelStyle{color(255, 255, 255), headerBrush}
	label("GameName", titleFont, color(255, 255, 255), headerBrush, 88, 8, 400, 32)
	label("Choose a list and generate a name.", smallFont, color(216, 201, 237), headerBrush, 90, 43, 540, 20)

	ink, muted := color(30, 24, 39), color(89, 78, 104)
	label("Name lists", sectionFont, ink, cardBrush, 42, 109, 250, 28)
	label("Double-click a list to load it.", smallFont, muted, cardBrush, 42, 143, 270, 22)
	setBox = control("LISTBOX", "", 0x00210101, 109, 42, 172, 272, 268)
	control("BUTTON", "Load File", 0x10000, 105, 42, 455, 129, 32)
	control("BUTTON", "Open File...", 0x10000, 101, 185, 455, 129, 32)

	label("Generate names", sectionFont, ink, cardBrush, 372, 109, 340, 28)
	label("Gender", font, ink, cardBrush, 372, 154, 140, 24)
	maleButton = control("BUTTON", "Male", 0x30009, 110, 372, 183, 97, 25)
	femaleButton = control("BUTTON", "Female", 0x10009, 111, 480, 183, 106, 25)
	send.Call(maleButton, 0xf1, 1, 0)
	label("Middle name", font, ink, cardBrush, 372, 222, 150, 24)
	noMiddleButton = control("BUTTON", "Without middle name", 0x30009, 112, 372, 250, 189, 25)
	middleButton = control("BUTTON", "With middle name", 0x10009, 113, 572, 250, 198, 25)
	send.Call(noMiddleButton, 0xf1, 1, 0)

	label("Count", font, ink, cardBrush, 632, 154, 142, 24)
	countBox = control("EDIT", "1", 0x00012080, 114, 632, 181, 142, 27)
	send.Call(countBox, 0xc5, 3, 0)
	control("BUTTON", "Generate", 0x10001, 102, 372, 281, 136, 30)
	control("BUTTON", "Copy", 0x10000, 103, 519, 281, 100, 30)
	label("Results", smallFont, muted, cardBrush, 372, 319, 180, 20)
	resultBox = control("EDIT", "", 0x00210844, 0, 372, 341, 402, 73)
	statusBox = control("EDIT", "Load a name list to get started.", 0x00200844, 0, 372, 421, 402, 66)
	send.Call(statusBox, 0x30, smallFont, 1)

	exe, _ := os.Executable()
	folder := filepath.Join(filepath.Dir(exe), "names")
	if config := configPath(); config != "" {
		if previous, err := os.ReadFile(config); err == nil {
			path := string(previous)
			if _, err := os.Stat(path); err == nil {
				populateLists(filepath.Dir(path), path)
				load(path)
			}
		}
	}
	if activePath == "" {
		populateLists(folder, "")
	}
	if !showSplash() {
		user.NewProc("ShowWindow").Call(window, 1)
	}
	var event message
	for {
		next, _, _ := user.NewProc("GetMessageW").Call(uintptr(unsafe.Pointer(&event)), 0, 0, 0)
		if int32(next) <= 0 {
			break
		}
		if splashPixels == nil {
			handled, _, _ := user.NewProc("IsDialogMessageW").Call(window, uintptr(unsafe.Pointer(&event)))
			if handled != 0 {
				continue
			}
		}
		user.NewProc("TranslateMessage").Call(uintptr(unsafe.Pointer(&event)))
		user.NewProc("DispatchMessageW").Call(uintptr(unsafe.Pointer(&event)))
	}
}
