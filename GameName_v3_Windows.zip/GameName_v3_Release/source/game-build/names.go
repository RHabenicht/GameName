package main

import (
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"unicode/utf8"
)

type nameList struct {
	male, female, family []string
	familyFirst          bool
	comment              string
}

func loadList(path string) (nameList, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nameList{}, err
	}
	return parseList(data)
}

func parseList(data []byte) (nameList, error) {
	var list nameList
	content := string(data)
	if !utf8.Valid(data) {
		const cp1252 = "€\u0081‚ƒ„…†‡ˆ‰Š‹Œ\u008dŽ\u008f\u0090‘’“”•–—˜™š›œ\u009džŸ"
		special := []rune(cp1252)
		var b strings.Builder
		for _, v := range data {
			if v >= 0x80 && v <= 0x9f {
				b.WriteRune(special[v-0x80])
			} else {
				b.WriteRune(rune(v))
			}
		}
		content = b.String()
	}
	lines := strings.Split(strings.TrimPrefix(content, "\ufeff"), "\n")
	for i := 0; i < len(lines); i++ {
		key := strings.TrimSpace(lines[i])
		if key == "COMMENT" && i+1 < len(lines) {
			list.comment = strings.Trim(strings.TrimSpace(lines[i+1]), "\"")
		}
		if setting, value, ok := strings.Cut(key, "="); ok &&
			strings.EqualFold(strings.TrimSpace(setting), "family name first") {
			list.familyFirst = strings.EqualFold(strings.TrimSpace(value), "true")
		}
		var table *[]string
		switch key {
		case "MALE":
			table = &list.male
		case "FEMALE":
			table = &list.female
		case "LAST NAMES":
			table = &list.family
		default:
			continue
		}
		i++
		for i < len(lines) && strings.TrimSpace(lines[i]) == "" {
			i++
		}
		if i == len(lines) {
			return list, fmt.Errorf("missing %s row count", key)
		}
		count, err := strconv.Atoi(strings.TrimSpace(lines[i]))
		if err != nil || count < 0 || count >= len(lines)-i {
			return list, fmt.Errorf("invalid %s row count", key)
		}
		for j := 0; j < count; j++ {
			i++
			row := strings.TrimSpace(lines[i])
			split := strings.IndexAny(row, " \t")
			number, value := row, ""
			if split >= 0 {
				number, value = row[:split], strings.TrimSpace(row[split:])
			}
			if _, err := strconv.Atoi(number); err != nil {
				return list, fmt.Errorf("invalid %s row %d", key, j+1)
			}
			*table = append(*table, value)
		}
	}
	if len(list.male)+len(list.female)+len(list.family) == 0 {
		return list, fmt.Errorf("this file has no names")
	}
	return list, nil
}

func (list nameList) generate(gender, count int) ([]string, error) {
	return list.generateWithMiddle(gender, count, false)
}

func (list nameList) generateWithMiddle(gender, count int, middle bool) ([]string, error) {
	given := list.male
	switch gender {
	case 2:
		given = list.female
	case 0:
		given = nil
		seen := make(map[string]bool)
		for _, pool := range [][]string{list.male, list.female} {
			for _, value := range pool {
				key := strings.ToLower(value)
				if !seen[key] {
					given = append(given, value)
					seen[key] = true
				}
			}
		}
	}
	if len(given) == 0 && len(list.male)+len(list.female) > 0 {
		return nil, fmt.Errorf("this list has no entries for that gender")
	}
	pick := func(pool []string) string {
		if len(pool) == 0 {
			return ""
		}
		return pool[rand.Intn(len(pool))]
	}
	results := make([]string, count)
	for i := range results {
		first, last := pick(given), pick(list.family)
		if middle && len(given) > 0 && len(list.family) > 0 {
			first = strings.TrimSpace(first + " " + pick(given))
		}
		if list.familyFirst {
			first, last = last, first
		}
		results[i] = strings.TrimSpace(first + " " + last)
	}
	return results, nil
}

func letterName(scrabble bool) string {
	const alphabet = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	const tiles = " AAAAAABBCCDDDDDEEEEEEEEEEEEEEEEEEFGGGGHHHIIIIIIJJKKLLLMMNNNNNNNNOOOOOOPPQRRRRRRSSSTTTTTTUUVVWWXYZZ"
	length := 4 + rand.Intn(10)
	result := make([]byte, length)
	if scrabble {
		bag := []byte(tiles)
		for i := range result {
			j := rand.Intn(len(bag))
			result[i] = bag[j]
			bag = append(bag[:j], bag[j+1:]...)
		}
	} else {
		for i := range result {
			result[i] = alphabet[rand.Intn(len(alphabet))]
		}
	}
	return strings.TrimSpace(string(result))
}
