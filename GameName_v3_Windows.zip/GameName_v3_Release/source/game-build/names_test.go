package main

import (
	"path/filepath"
	"slices"
	"strings"
	"testing"
)

func TestPackagedNameLists(t *testing.T) {
	files, err := filepath.Glob("../gamename-desktop/names/*.nam")
	if err != nil || len(files) != 36 {
		t.Fatalf("expected 36 lists; got %d: %v", len(files), err)
	}
	for _, path := range files {
		list, err := loadList(path)
		if err != nil {
			t.Errorf("%s: %v", path, err)
			continue
		}
		names, err := list.generate(0, 5)
		if err != nil || len(names) != 5 {
			t.Errorf("%s: %v, %v", path, names, err)
		}
	}
}

func TestClassicNameControls(t *testing.T) {
	list := nameList{male: []string{"Jan"}, female: []string{"Anna"}, family: []string{"Vos"}}
	for _, tc := range []struct {
		gender int
		middle bool
		want   string
	}{
		{1, false, "Jan Vos"}, {2, false, "Anna Vos"}, {1, true, "Jan Jan Vos"}, {2, true, "Anna Anna Vos"},
	} {
		names, err := list.generateWithMiddle(tc.gender, 1, tc.middle)
		if err != nil || len(names) != 1 || names[0] != tc.want {
			t.Fatalf("got %v, %v; want %s", names, err, tc.want)
		}
	}
	for _, scrabble := range []bool{false, true} {
		for i := 0; i < 100; i++ {
			if len(letterName(scrabble)) > 13 {
				t.Fatal("letter name too long")
			}
		}
	}
}

func TestChineseNames(t *testing.T) {
	list, err := loadList("../gamename-desktop/names/ChineseNames.nam")
	if err != nil {
		t.Fatal(err)
	}
	if !list.familyFirst || len(list.family) == 0 || len(list.male) == 0 || len(list.female) == 0 {
		t.Fatal("Chinese export must have surname-first order and three populated tables")
	}
	for gender, pool := range map[int][]string{1: list.male, 2: list.female} {
		results, err := list.generate(gender, 200)
		if err != nil {
			t.Fatal(err)
		}
		for _, result := range results {
			fields := strings.Fields(result)
			if len(fields) != 2 || !slices.Contains(list.family, fields[0]) ||
				!slices.Contains(pool, fields[1]) || strings.ContainsAny(result, "'*") {
				t.Fatalf("unexpected Chinese name: %q", result)
			}
		}
	}
}
