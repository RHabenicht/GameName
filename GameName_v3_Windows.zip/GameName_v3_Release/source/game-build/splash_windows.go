package main

import (
	"bytes"
	_ "embed"
	"image/png"
	"runtime"
	"syscall"
	"unsafe"
)

//go:embed GameName_Splash.png
var splashPNG []byte

const splashDurationMS = 6500

type splashBitmapHeader struct {
	size                        uint32
	width, height               int32
	planes, bits                uint16
	compression, imageSize      uint32
	xResolution, yResolution    int32
	colorsUsed, importantColors uint32
}

type splashPaint struct {
	dc              uintptr
	erase           int32
	area            rect
	restore, update int32
	reserved        [32]byte
}

var splashPixels []byte
var splashBitmap splashBitmapHeader
var splashPainted bool

func splashProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case 0x000f: // WM_PAINT
		var paint splashPaint
		dc, _, _ := user.NewProc("BeginPaint").Call(hwnd, uintptr(unsafe.Pointer(&paint)))
		if dc != 0 && len(splashPixels) != 0 {
			width, height := uintptr(splashBitmap.width), uintptr(splashBitmap.height)
			lines, _, _ := gdi.NewProc("SetDIBitsToDevice").Call(dc, 0, 0, width, height,
				0, 0, 0, height, uintptr(unsafe.Pointer(&splashPixels[0])),
				uintptr(unsafe.Pointer(&splashBitmap)), 0)
			splashPainted = int32(lines) > 0
		}
		user.NewProc("EndPaint").Call(hwnd, uintptr(unsafe.Pointer(&paint)))
		return 0
	case 0x0113: // WM_TIMER
		if wp == 1 {
			user.NewProc("KillTimer").Call(hwnd, wp)
			user.NewProc("DestroyWindow").Call(hwnd)
			user.NewProc("ShowWindow").Call(window, 1)
			splashPixels = nil
			return 0
		}
	case 0x0010: // WM_CLOSE
		return 0
	}
	result, _, _ := defWindow.Call(hwnd, uintptr(msg), wp, lp)
	return result
}

func showSplash() bool {
	art, err := png.Decode(bytes.NewReader(splashPNG))
	if err != nil {
		return false
	}
	bounds := art.Bounds()

	var area rect
	ok, _, _ := user.NewProc("SystemParametersInfoW").Call(0x0030, 0, uintptr(unsafe.Pointer(&area)), 0)
	if ok == 0 {
		return false
	}
	width, height := int(area.right-area.left), int(area.bottom-area.top)
	if width < 1 || height < 1 {
		return false
	}
	w := min(int(px(760)), width*9/10)
	h := w * bounds.Dy() / bounds.Dx()
	if h > height*9/10 {
		h = height * 9 / 10
		w = h * bounds.Dx() / bounds.Dy()
	}
	if w < 1 || h < 1 {
		return false
	}

	// Scale to the window size before painting. A 32-bit DIB uses BGRX
	// pixels, with the bottom row first when the bitmap height is positive.
	splashPixels = make([]byte, w*h*4)
	for y := 0; y < h; y++ {
		sourceY := bounds.Min.Y + y*bounds.Dy()/h
		for x := 0; x < w; x++ {
			sourceX := bounds.Min.X + x*bounds.Dx()/w
			r, g, b, _ := art.At(sourceX, sourceY).RGBA()
			i := ((h-1-y)*w + x) * 4
			splashPixels[i], splashPixels[i+1], splashPixels[i+2] = byte(b>>8), byte(g>>8), byte(r>>8)
		}
	}
	splashBitmap = splashBitmapHeader{
		size: 40, width: int32(w), height: int32(h), planes: 1, bits: 32,
	}
	className := ptr("GameNameSplash")
	class := windowClass{
		procedure: syscall.NewCallback(splashProc), instance: instance, name: className,
		background: headerBrush,
	}
	class.size = uint32(unsafe.Sizeof(class))
	registered, _, _ := user.NewProc("RegisterClassExW").Call(uintptr(unsafe.Pointer(&class)))
	if registered == 0 {
		splashPixels = nil
		return false
	}
	hwnd, _, _ := create.Call(0x88, uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(ptr("GameName"))), 0x80000000,
		uintptr(int(area.left)+(width-w)/2), uintptr(int(area.top)+(height-h)/2),
		uintptr(w), uintptr(h), 0, 0, instance, 0)
	runtime.KeepAlive(className)
	if hwnd == 0 {
		splashPixels = nil
		return false
	}
	// The first ShowWindow can inherit a launcher setting that hides the window.
	// Show it explicitly before painting and starting the display timer.
	user.NewProc("ShowWindow").Call(hwnd, 1)
	const showWithoutMoving = 0x0040 | 0x0010 | 0x0004 | 0x0002 | 0x0001
	shown, _, _ := user.NewProc("SetWindowPos").Call(hwnd, 0, 0, 0, 0, 0, showWithoutMoving)
	if shown != 0 {
		user.NewProc("UpdateWindow").Call(hwnd)
		if splashPainted {
			timer, _, _ := user.NewProc("SetTimer").Call(hwnd, 1, splashDurationMS, 0)
			if timer != 0 {
				return true
			}
		}
	}
	user.NewProc("DestroyWindow").Call(hwnd)
	splashPixels = nil
	return false
}
