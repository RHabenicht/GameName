GameName v3
Windows 10 and Windows 11 (64-bit)

GameName v3 is NightLife’s update of the name generator written by Gurth
(v1) and later ported by Tobias Diekershoff (v2).

Install
-------
Extract the ZIP and run GameName_v3_Setup.exe. Open GameName from the
Start menu. Setup installs 36 name lists. To remove the program, choose
Uninstall GameName from the Start menu.

Generate a name
---------------
Double-click a list or select it and click Load File. Choose Male or
Female, then choose whether to include a middle name. Enter a Count
from 1 to 100 and click Generate. The default is 1. Click Copy to
copy all the results.

Use Open File to load your own .nam file. For a name made from letters,
choose Random Name or Scrabble Name from the Generate menu. Both
commands use the same Count field.

Make your own lists
-------------------
See MAKE_NAME_LISTS.txt for manual editing and an AI prompt. The examples
folder contains two .nam files you can open in GameName.

Included lists
--------------
American English, British English, Australian English, and New Zealand
English have separate files. The bundled .nam files are also available
under source/gamename-desktop/names.
Chinese names use Mandarin romanization with the surname first.
Danish, Dutch, German, Hindi, Irish, Italian, and Japanese each use one
combined list. The Japanese list uses stored names, including entries from
JapaneseNames.ipt. Its syllable generator is excluded.

Some lists contain a fixed sample of names drawn from an Inspiration
Pad Pro generator. See source/gamename-desktop/EXPORTS.json for the
conversion method and credits.

License and source
------------------
GameName v3 is released under the GNU General Public License, version 3
or any later version. COPYING.txt contains the full GPLv3 text.
See source/BUILD.txt to rebuild the program and installer.

All 36 bundled lists passed generation tests. Windows installation and
splash timing still need testing.
